package com.fpmislata.evalexamencarlostornero.exception;

public class ResourceNotFoundException extends RuntimeException{
    public ResourceNotFoundException(String mesage){
        super(mesage);
    }
}
